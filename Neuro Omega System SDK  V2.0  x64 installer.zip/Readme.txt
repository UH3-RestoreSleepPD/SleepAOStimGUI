Installation Instructions

1- Run Neuro Omega System SDK V2.0.exe
2- Relevant for win10 only:- Check which Winpcap version installed on the computer? 
3- Relevant for win10 only:- Uninstall any older version than Winpcap 4.1.3 and install Winpcap 4.1.3 (installation file attached in same folder)

MATLAB setup
1- Open Matlab
2- Add the installation path to the workspace folder
3- run commands